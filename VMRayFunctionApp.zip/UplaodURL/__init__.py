import json
import logging
from datetime import datetime
from os import environ
from urllib.parse import urlencode, urlunparse

import azure.functions as func
import requests

DATE_TIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
DEFAULT_HEADERS = {"accept": "application/json", "Content-Type": "application/json"}
vmray_api_key = environ["vmrayAPIKey"]
vmrayBaseURL = environ["vmrayBaseURL"]


def do_request(endpoint, params={}, body={}):
    # import pdb; pdb.set_trace()
    headers = {
        "Authorization": f"api_key {vmray_api_key}",
        "User-Agent": "Sentinel"
    }

    try:
        response = requests.post(
            url=f'{vmrayBaseURL}/rest/{endpoint}',
            headers=headers,
            params=params
        )
        response.raise_for_status()  # Raises HTTPError for bad responses
        logging.info(f'User-Agent: {response.request.headers.get("User-Agent")}')
        return response
    except requests.exceptions.RequestException as e:
        logging.error(f"Error in request: {e}")
        logging.error(f"Error response: {response.json().get('error_msg')}")
        return response


def build_submission_data(raw_response, type_):
    """Process a submission response from VMRay Platform

    Args:
        raw_response: (dict)
        type_: (str)
    """

    data = raw_response.get('data')

    jobs_list = []
    jobs = data.get('jobs', [])
    for job in jobs:
        if isinstance(job, dict):
            job_entry = {}
            job_entry['JobID'] = job.get('job_id')
            job_entry['Created'] = job.get('job_created')
            job_entry['SampleID'] = job.get('job_sample_id')
            job_entry['VMName'] = job.get('job_vm_name')
            job_entry['VMID'] = job.get('job_vm_id')
            job_entry['JobRuleSampleType'] = job.get('job_jobrule_sampletype')
            jobs_list.append(job_entry)

    samples_list = []
    samples = data.get('samples', [])
    for sample in samples:
        if isinstance(sample, dict):
            sample_entry = {}
            sample_entry['SampleID'] = sample.get('sample_id')
            sample_entry['SampleURL'] = sample.get('sample_webif_url')
            sample_entry['Created'] = sample.get('sample_created')
            sample_entry['FileName'] = sample.get('submission_filename')
            sample_entry['FileSize'] = sample.get('sample_filesize')
            sample_entry['SSDeep'] = sample.get('sample_ssdeephash')
            sample_entry['SHA1'] = sample.get('sample_sha1hash')
            samples_list.append(sample_entry)

    submissions_list = []
    submissions = data.get('submissions', [])
    for submission in submissions:
        if isinstance(submission, dict):
            submission_entry = {}
            submission_entry['SubmissionID'] = submission.get('submission_id')
            submission_entry['SubmissionURL'] = submission.get('submission_webif_url')
            submission_entry['SampleID'] = submission.get('submission_sample_id')
            submissions_list.append(submission_entry)

    entry_context = {}
    entry_context['vmray_job'] = jobs_list
    entry_context['vmray_sample'] = samples_list
    entry_context[
        'vmray_submission'
    ] = submissions_list

    # table = {
    #     'Jobs ID': [job.get('JobID') for job in jobs_list],
    #     'Samples ID': [sample.get('SampleID') for sample in samples_list],
    #     'Submissions ID': [
    #         submission.get('SubmissionID') for submission in submissions_list
    #     ],
    #     'Sample URL': [sample.get('SampleURL') for sample in samples_list],
    # }
    return entry_context


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        url = req.params.get("url")
        shareable = req.params.get("shareable")
        max_jobs = req.params.get("max_jobs")
        tags = req.params.get("tags", [])
        net_scheme_name = req.params.get("net_scheme_name", [])

        if not url:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                url = req_body.get("url")
                shareable = req_body.get("shareable")
                max_jobs = req_body.get("max_jobs")
                tags = req_body.get("tags", [])
                net_scheme_name = req_body.get("net_scheme_name")
        params = {}
        params['shareable'] = shareable == 'true'
        if max_jobs:
            if isinstance(max_jobs, str) and max_jobs.isdigit() or isinstance(max_jobs, int):
                params['max_jobs'] = int(max_jobs)
            else:
                raise ValueError('max_jobs arguments isn\'t a number')
        if tags:
            params['tags'] = ",".join(tags)
        if net_scheme_name:
            params['user_config'] = "{\"net_scheme_name\": \"" + str(net_scheme_name) + "\"}"
        endpoint = "sample/submit"
        params['sample_url'] = url
        response = do_request(endpoint, params)
        submission_data = build_submission_data(response.json(), "url")
        return func.HttpResponse(
            json.dumps(submission_data),
            headers={"Content-Type": "application/json"},
            status_code=200,
        )

    except KeyError as ke:
        logging.error(f"Invalid Settings. {ke.args} configuration is missing.")
        return func.HttpResponse(
            "Invalid Settings. Configuration is missing.", status_code=500
        )
    except Exception as ex:
        logging.error(f"Exception Occured: {str(ex)}")
        return func.HttpResponse("Internal Server Exception", status_code=500)
