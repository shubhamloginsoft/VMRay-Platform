import json
import logging

import azure.functions as func
from future.backports.http.client import responses

from  ..VMRay import VMRay
from ..const import *


vmray = VMRay(log)

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        hash = req.params.get("hash")
        if not hash:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                hash = req_body.get("hash")
        logging.info(f"hash {hash}")
        hash_type_lookup = {
            32: "md5",
            40: "sha1",
            64: "sha256"
        }
        hash_type = hash_type_lookup.get(len(hash))
        if hash_type is None:
            error_string = " or ".join(f"{len_} ({type_})" for len_, type_ in hash_type_lookup.items())
            raise ValueError(
                f'Invalid hash provided, must be of length {error_string}. '
                f'Provided hash had a length of {len(hash)}.'
            )
        response = vmray.get_sample(hash)
        parse_sample = {}
        if response:
            parse_sample = vmray.parse_sample_data(response)

        return func.HttpResponse(
            json.dumps(parse_sample),
            headers={"Content-Type": "application/json"},
            status_code=200,
        )
    except KeyError as ke:
        logging.error(f"Invalid Settings. {ke.args} configuration is missing.")
        return func.HttpResponse(
            "Invalid Settings. Configuration is missing.", status_code=500
        )
    except Exception as ex:
        logging.error(f"Exception Occured: {str(ex)}")
        return func.HttpResponse("Internal Server Exception", status_code=500)
