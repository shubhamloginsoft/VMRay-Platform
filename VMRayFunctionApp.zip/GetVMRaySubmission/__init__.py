import json
import logging
from datetime import datetime
from os import environ
from urllib.parse import urlencode, urlunparse

import azure.functions as func
import requests

DATE_TIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
DEFAULT_HEADERS = {"accept": "application/json", "Content-Type": "application/json"}
vmray_api_key = environ["vmrayAPIKey"]
vmrayBaseURL = environ["vmrayBaseURL"]


def do_request(endpoint, params={}, body={}):
    # import pdb; pdb.set_trace()
    headers = {
        "Authorization": f"api_key {vmray_api_key}",
        "User-Agent": "Sentinel"
    }

    try:
        logging.info(f"api key {vmray_api_key}")
        logging.info(f"api ur {vmrayBaseURL}")
        response = requests.get(
            url=f'{vmrayBaseURL}/rest/{endpoint}',
            headers=headers,
            params=params
        )
        response.raise_for_status()  # Raises HTTPError for bad responses
        logging.info(f'User-Agent: {response.request.headers.get("User-Agent")}')
        return response
    except requests.exceptions.RequestException as e:
        logging.error(f"Error in request: {e}")
        logging.error(f"Error response: {response.json().get('error_msg')}")
        return response


def check_id(id_to_check: int | str) -> bool:
    """Checks if parameter id_to_check is a number

    Args:
        id_to_check (int or str):

    Returns:
        bool: True if is a number, else returns error
    """
    if isinstance(id_to_check, int) or isinstance(id_to_check, str) and id_to_check.isdigit():
        return True
    raise ValueError(f"Invalid ID `{id_to_check}` provided.")



def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        submission_id = req.params.get("submission_id")
        if not submission_id:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                submission_id = req_body.get("submission_id")
        logging.info(f"submission_id {submission_id}")
        check_id(submission_id)

        endpoint = f'submission/{submission_id}'
        response = do_request(endpoint)
        return func.HttpResponse(
            json.dumps(response.json()),
            headers={"Content-Type": "application/json"},
            status_code=200,
        )
    except KeyError as ke:
        logging.error(f"Invalid Settings. {ke.args} configuration is missing.")
        return func.HttpResponse(
            "Invalid Settings. Configuration is missing.", status_code=500
        )
    except Exception as ex:
        logging.error(f"Exception Occured: {str(ex)}")
        return func.HttpResponse("Internal Server Exception", status_code=500)
