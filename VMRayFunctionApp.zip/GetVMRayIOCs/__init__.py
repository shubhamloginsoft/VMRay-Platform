import json
import logging
from datetime import datetime
from os import environ
from urllib.parse import urlencode, urlunparse

import azure.functions as func
import requests

DATE_TIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
DEFAULT_HEADERS = {"accept": "application/json", "Content-Type": "application/json"}
vmray_api_key = environ["vmrayAPIKey"]
vmrayBaseURL = environ["vmrayBaseURL"]


def do_request(endpoint, params={}, body={}):
    # import pdb; pdb.set_trace()
    headers = {
        "Authorization": f"api_key {vmray_api_key}",
        "User-Agent": "Sentinel"
    }

    try:
        logging.info(f"api key {vmray_api_key}")
        logging.info(f"api ur {vmrayBaseURL}")
        response = requests.get(
            url=f'{vmrayBaseURL}/rest/{endpoint}',
            headers=headers,
            params=params
        )
        response.raise_for_status()  # Raises HTTPError for bad responses
        logging.info(f'User-Agent: {response.request.headers.get("User-Agent")}')
        return response
    except requests.exceptions.RequestException as e:
        logging.error(f"Error in request: {e}")
        logging.error(f"Error response: {response.json().get('error_msg')}")
        return response



def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        hash = req.params.get("hash")
        if not hash:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                hash = req_body.get("hash")
        logging.info(f"hash {hash}")
        hash_type_lookup = {
            32: "md5",
            40: "sha1",
            64: "sha256"
        }
        hash_type = hash_type_lookup.get(len(hash))
        if hash_type is None:
            error_string = " or ".join(f"{len_} ({type_})" for len_, type_ in hash_type_lookup.items())
            raise ValueError(
                f'Invalid hash provided, must be of length {error_string}. '
                f'Provided hash had a length of {len(hash)}.'
            )
        endpoint = f'sample/{hash_type}/{hash}'
        response = do_request(endpoint)
        return func.HttpResponse(
            json.dumps(response.json()),
            headers={"Content-Type": "application/json"},
            status_code=200,
        )
    except KeyError as ke:
        logging.error(f"Invalid Settings. {ke.args} configuration is missing.")
        return func.HttpResponse(
            "Invalid Settings. Configuration is missing.", status_code=500
        )
    except Exception as ex:
        logging.error(f"Exception Occured: {str(ex)}")
        return func.HttpResponse("Internal Server Exception", status_code=500)
