import json
import logging

import azure.functions as func

from  ..VMRay import VMRay
from ..const import *


vmray = VMRay(log)


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        sample_id = req.params.get("sample_id")
        if not sample_id:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                sample_id = req_body.get("sample_id")
        logging.info(f"Sample {sample_id}")
        sample = vmray.get_sample(sample_id, True)
        sampe_iocs = vmray.get_sample_iocs(sample)
        parse_iocs = vmray.parse_sample_iocs(sampe_iocs)
        return func.HttpResponse(
            json.dumps(parse_iocs),
            headers={"Content-Type": "application/json"},
            status_code=200,
        )
    except KeyError as ke:
        logging.error(f"Invalid Settings. {ke.args} configuration is missing.")
        return func.HttpResponse(
            "Invalid Settings. Configuration is missing.", status_code=500
        )
    except Exception as ex:
        logging.error(f"Exception Occured: {str(ex)}")
        return func.HttpResponse("Internal Server Exception", status_code=500)

