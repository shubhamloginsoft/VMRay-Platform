import json
import logging
import random
import time
import io
import base64
from datetime import datetime
from os import environ
from urllib.parse import urlencode, urlunparse

import azure.functions as func
import requests

DATE_TIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
DEFAULT_HEADERS = {"accept": "application/json", "Content-Type": "application/json"}
vmray_api_key = environ["vmrayAPIKey"]
vmrayBaseURL = environ["vmrayBaseURL"]
HEADERS = {
        "Authorization": f"api_key {vmray_api_key}",
        "User-Agent": "Sentinel"
    }
RATE_LIMIT_REACHED = 429
MAX_RETRIES = 10
RETRY_ON_RATE_LIMIT=True
ERROR_FORMAT = 'Error in API call to VMRay [{}] - {}'


def is_json(response):
    """Checks if response is jsonable

    Args:
        response (requests.Response):

    Returns:
        bool: true if object is jsonable
    """
    try:
        response.json()
    except ValueError:
        return False
    return True
def do_request(endpoint, params={}, body={}, files=None):
    headers = {
        "Authorization": f"api_key {vmray_api_key}",
        "User-Agent": "Sentinel"
    }

    try:
        response = requests.post(
            url=f'{vmrayBaseURL}/rest/{endpoint}',
            headers=headers,
            params=params,
            files=files
        )
        response.raise_for_status()  # Raises HTTPError for bad responses
        logging.info(f'User-Agent: {response.request.headers.get("User-Agent")}')
        return response
    except requests.exceptions.RequestException as e:
        logging.error(f"Error in request: {e}")
        logging.error(f"Error response: {response.json().get('error_msg')}")
        return response


def build_errors_string(errors):
    """

    Args:
        errors (list, dict or unicode):

    Returns:
        str: error message
    """
    if isinstance(errors, str):
        return str(errors)
    elif isinstance(errors, list):
        err_str = ''
        for error in errors:
            err_str += error.get('error_msg') + '.\n'
    else:
        err_str = errors.get('error_msg')
    return err_str


# def http_request(method, url_suffix, params=None, files=None, ignore_errors=False, get_raw=False, retries=0):
#     """ General HTTP request.
#     Args:
#         ignore_errors (bool):
#         method: (str) 'GET', 'POST', 'DELETE' 'PUT'
#         url_suffix: (str)
#         params: (dict)
#         files: (dict)
#         get_raw: (bool) return raw data instead of dict
#         retries: (int)

#     Returns:
#         dict: response json
#     """

#     def find_error(may_be_error_inside):
#         """Function will search for dict with 'errors' or 'error_msg' key

#         Args:
#             may_be_error_inside: object, any object

#         Returns:
#             None if no error presents
#             Errors list/string if errors inside.
#         """
#         if isinstance(may_be_error_inside, list):
#             for obj in may_be_error_inside:
#                 ans = find_error(obj)
#                 if ans:
#                     return ans
#             return None
#         if isinstance(may_be_error_inside, dict):
#             if 'error_msg' in may_be_error_inside:
#                 return may_be_error_inside['error_msg']
#             if 'errors' in may_be_error_inside and may_be_error_inside.get('errors'):
#                 return may_be_error_inside['errors']
#             for value in may_be_error_inside.values():
#                 err_r = find_error(value)
#                 if err_r:
#                     return err_r
#         return None

#     def reset_file_buffer(files):
#         """ The requests library reads the file buffer to the end.
#             If we want to try to submit again, we need to set the file buffer to
#             beginning manually.
#         Args:
#             files: (dict)
#         """

#         if not isinstance(files, dict):
#             return

#         try:
#             fobj = files["sample_file"][1]
#             fobj.seek(0, 0)
#         except (IndexError, KeyError):
#             return

#     url = f'{vmrayBaseURL}/rest/{url_suffix}'
#     r = requests.request(
#         method, url, params=params, headers=HEADERS, files=files
#     )

#     if RETRY_ON_RATE_LIMIT and retries < MAX_RETRIES \
#             and (r.status_code == RATE_LIMIT_REACHED or "Retry-After" in r.headers):
#         seconds_to_wait = random.uniform(1.0, 5.0)
#         try:
#             seconds_to_wait += float(r.headers.get("Retry-After", 0))
#         except ValueError:
#             pass

#         logging.debug(f"Rate limit exceeded! Waiting {seconds_to_wait} seconds and then retry #{retries}.")
#         time.sleep(seconds_to_wait)  # pylint: disable=sleep-exists
#         reset_file_buffer(files)
#         return http_request(method, url_suffix, params, files, ignore_errors, get_raw, retries + 1)

#     # Handle errors
#     try:
#         if r.status_code in {405, 401}:
#             return func.HttpResponse(
#                 json.dumps({'message': ERROR_FORMAT.format(r.status_code, 'Token may be invalid')}),
#                 headers={"Content-Type": "application/json"},
#                 status_code=r.status_code
#                 )
#         elif not get_raw and not is_json(r):
#             raise ValueError
#         response = r.json() if not get_raw else r.content
#         if r.status_code not in {200, 201, 202, 204} and not ignore_errors:
#             if get_raw and isinstance(response, str):
#                 # this might be json even if get_raw is True because the API will return errors as json
#                 try:
#                     response = json.loads(response)
#                 except ValueError:
#                     pass
#             err = find_error(response)
#             if not err:
#                 err = r.text
#             return func.HttpResponse(
#                 json.dumps({'message': ERROR_FORMAT.format(r.status_code, err)}),
#                 headers={"Content-Type": "application/json"},
#                 status_code=r.status_code
#                 )

#         err = find_error(response)
#         if err:
#             if "no jobs were created" in build_errors_string(err):
#                 err_message = err[0].get("error_msg") + '. There is a possibility this file has been analyzed ' \
#                                                         'before. Please change the Analysis Caching mode for this ' \
#                                                         'API key to something other than "Legacy" in the VMRay ' \
#                                                         'Web Interface.'
#                 err[0]['error_msg'] = err_message
#             return func.HttpResponse(
#                 json.dumps({'message': ERROR_FORMAT.format(r.status_code, err)}),
#                 headers={"Content-Type": "application/json"},
#                 status_code=r.status_code
#                 )
#         return response
#     except ValueError:
#         # If no JSON is present, must be an error that can't be ignored
#         return func.HttpResponse(
#                 json.dumps({'message': ERROR_FORMAT.format(r.status_code, r.text)}),
#                 headers={"Content-Type": "application/json"},
#                 status_code=r.status_code
#                 )


def build_submission_data(raw_response, type_):
    """Process a submission response from VMRay Platform

    Args:
        raw_response: (dict)
        type_: (str)
    """

    data = raw_response.get('data')

    jobs_list = []
    jobs = data.get('jobs', [])
    for job in jobs:
        if isinstance(job, dict):
            job_entry = {}
            job_entry['JobID'] = job.get('job_id')
            job_entry['Created'] = job.get('job_created')
            job_entry['SampleID'] = job.get('job_sample_id')
            job_entry['VMName'] = job.get('job_vm_name')
            job_entry['VMID'] = job.get('job_vm_id')
            job_entry['JobRuleSampleType'] = job.get('job_jobrule_sampletype')
            jobs_list.append(job_entry)

    samples_list = []
    samples = data.get('samples', [])
    for sample in samples:
        if isinstance(sample, dict):
            sample_entry = {}
            sample_entry['SampleID'] = sample.get('sample_id')
            sample_entry['SampleURL'] = sample.get('sample_webif_url')
            sample_entry['Created'] = sample.get('sample_created')
            sample_entry['FileName'] = sample.get('submission_filename')
            sample_entry['FileSize'] = sample.get('sample_filesize')
            sample_entry['SSDeep'] = sample.get('sample_ssdeephash')
            sample_entry['SHA1'] = sample.get('sample_sha1hash')
            samples_list.append(sample_entry)

    submissions_list = []
    submissions = data.get('submissions', [])
    for submission in submissions:
        if isinstance(submission, dict):
            submission_entry = {}
            submission_entry['SubmissionID'] = submission.get('submission_id')
            submission_entry['SubmissionURL'] = submission.get('submission_webif_url')
            submission_entry['SampleID'] = submission.get('submission_sample_id')
            submissions_list.append(submission_entry)

    entry_context = {}
    entry_context['vmray_job'] = jobs_list
    entry_context['vmray_sample'] = samples_list
    entry_context[
        'vmray_submission'
    ] = submissions_list

    # table = {
    #     'Jobs ID': [job.get('JobID') for job in jobs_list],
    #     'Samples ID': [sample.get('SampleID') for sample in samples_list],
    #     'Submissions ID': [
    #         submission.get('SubmissionID') for submission in submissions_list
    #     ],
    #     'Sample URL': [sample.get('SampleURL') for sample in samples_list],
    # }
    return entry_context


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        file = req.params.get("file")
        name = req.params.get('name')
        doc_pass = req.params.get('document_password')
        arch_pass = req.params.get('archive_password')
        sample_type = req.params.get('sample_type')
        shareable = req.params.get("shareable")
        max_jobs = req.params.get("max_jobs")
        tags = req.params.get("tags", [])
        net_scheme_name = req.params.get("net_scheme_name", [])

        if not file:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                file = req_body.get("file")
                name = req_body.get('name')
                doc_pass = req_body.get('document_password')
                arch_pass = req_body.get('archive_password')
                sample_type = req_body.get('sample_type')
                shareable = req_body.get("shareable")
                max_jobs = req_body.get("max_jobs")
                tags = req_body.get("tags", [])
                net_scheme_name = req_body.get("net_scheme_name")
        binary_data = base64.b64decode(file)
        file_object = io.BytesIO(binary_data)
        params = {}
        params['shareable'] = shareable == 'true'
        if doc_pass:
            params['document_password'] = doc_pass
        if arch_pass:
            params['archive_password'] = arch_pass
        if sample_type:
            params['sample_type'] = sample_type
        if max_jobs:
            if isinstance(max_jobs, str) and max_jobs.isdigit() or isinstance(max_jobs, int):
                params['max_jobs'] = int(max_jobs)
            else:
                raise ValueError('max_jobs arguments isn\'t a number')
        if tags:
            params['tags'] = ",".join(tags)
        if net_scheme_name:
            params['user_config'] = "{\"net_scheme_name\": \"" + str(net_scheme_name) + "\"}"
        endpoint = "sample/submit"
        files = {"sample_file" :(name, file_object)}
        response = do_request(endpoint, params=params, files=files)
        submission_data = build_submission_data(response.json(), "File")
        return func.HttpResponse(
            json.dumps(submission_data),
            headers={"Content-Type": "application/json"},
            status_code=200,
        )

    except KeyError as ke:
        logging.error(f"Invalid Settings. {ke.args} configuration is missing.")
        return func.HttpResponse(
            "Invalid Settings. Configuration is missing.", status_code=500
        )
    except Exception as ex:
        logging.error(f"Exception Occured: {str(ex)}")
        return func.HttpResponse("Internal Server Exception", status_code=500)

