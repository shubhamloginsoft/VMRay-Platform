import json
import logging
import io
import base64
import hashlib
from os import environ

import azure.functions as func
import requests


#helper function
def str_to_bool(value: str):
    if isinstance(value, str):
        value = value.strip().lower()
        if value == "false":
            return False
        elif value == "true":
            return True
    return bool(value)


DATE_TIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
DEFAULT_HEADERS = {"accept": "application/json", "Content-Type": "application/json"}
vmray_api_key = environ["vmrayAPIKey"]
vmrayBaseURL = environ["vmrayBaseURL"]
resubmit = str_to_bool(environ["Resubmit"])
HEADERS = {
        "Authorization": f"api_key {vmray_api_key}",
        "User-Agent": "Sentinel"
    }
RATE_LIMIT_REACHED = 429
MAX_RETRIES = 10
RETRY_ON_RATE_LIMIT=True
ERROR_FORMAT = 'Error in API call to VMRay [{}] - {}'


def is_json(response):
    """Checks if response is jsonable

    Args:
        response (requests.Response):

    Returns:
        bool: true if object is jsonable
    """
    try:
        response.json()
    except ValueError:
        return False
    return True



def do_request(method, endpoint, params={}, files=None):
    headers = {
        "Authorization": f"api_key {vmray_api_key}",
        "User-Agent": "Sentinel"
    }

    try:
        if method == "GET":
            response = requests.get(url=endpoint, headers=headers)

        else:
            response = requests.post(
                url=f'{vmrayBaseURL}/rest/{endpoint}',
                headers=headers,
                params=params,
                files=files
            )
        response.raise_for_status()  # Raises HTTPError for bad responses
        logging.info(f'User-Agent: {response.request.headers.get("User-Agent")}')
        return response
    except requests.HTTPError as e:
        logging.error(f"Error in request: {e}")
        logging.error(f"Error response: {response.json().get('error_msg')}")
        raise Exception(e)


def build_errors_string(errors):
    """

    Args:
        errors (list, dict or unicode):

    Returns:
        str: error message
    """
    if isinstance(errors, str):
        return str(errors)
    elif isinstance(errors, list):
        err_str = ''
        for error in errors:
            err_str += error.get('error_msg') + '.\n'
    else:
        err_str = errors.get('error_msg')
    return err_str



def build_submission_data(raw_response, type_):
    """Process a submission response from VMRay Platform

    Args:
        raw_response: (dict)
        type_: (str)
    """

    data = raw_response.get('data')

    jobs_list = []
    jobs = data.get('jobs', [])
    for job in jobs:
        if isinstance(job, dict):
            job_entry = {}
            job_entry['JobID'] = job.get('job_id')
            job_entry['Created'] = job.get('job_created')
            job_entry['SampleID'] = job.get('job_sample_id')
            job_entry['VMName'] = job.get('job_vm_name')
            job_entry['VMID'] = job.get('job_vm_id')
            job_entry['JobRuleSampleType'] = job.get('job_jobrule_sampletype')
            jobs_list.append(job_entry)

    samples_list = []
    samples = data.get('samples', [])
    for sample in samples:
        if isinstance(sample, dict):
            sample_entry = {}
            sample_entry['SampleID'] = sample.get('sample_id')
            sample_entry['SampleURL'] = sample.get('sample_webif_url')
            sample_entry['Created'] = sample.get('sample_created')
            sample_entry['FileName'] = sample.get('submission_filename')
            sample_entry['FileSize'] = sample.get('sample_filesize')
            sample_entry['SSDeep'] = sample.get('sample_ssdeephash')
            sample_entry['SHA1'] = sample.get('sample_sha1hash')
            samples_list.append(sample_entry)

    submissions_list = []
    submissions = data.get('submissions', [])
    for submission in submissions:
        if isinstance(submission, dict):
            submission_entry = {}
            submission_entry['SubmissionID'] = submission.get('submission_id')
            submission_entry['SubmissionURL'] = submission.get('submission_webif_url')
            submission_entry['SampleID'] = submission.get('submission_sample_id')
            submissions_list.append(submission_entry)

    entry_context = {}
    entry_context['vmray_job'] = jobs_list
    entry_context['vmray_sample'] = samples_list
    entry_context[
        'vmray_submission'
    ] = submissions_list

    return entry_context


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        file = req.params.get("file")
        name = req.params.get('name')
        doc_pass = req.params.get('document_password')
        arch_pass = req.params.get('archive_password')
        sample_type = req.params.get('sample_type')
        shareable = req.params.get("shareable")
        max_jobs = req.params.get("max_jobs")
        tags = req.params.get("tags", [])
        net_scheme_name = req.params.get("net_scheme_name", [])

        if not file:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                file = req_body.get("file")
                name = req_body.get('name')
                doc_pass = req_body.get('document_password')
                arch_pass = req_body.get('archive_password')
                sample_type = req_body.get('sample_type')
                shareable = req_body.get("shareable")
                max_jobs = req_body.get("max_jobs")
                tags = req_body.get("tags", [])
                net_scheme_name = req_body.get("net_scheme_name")
        binary_data = base64.b64decode(file)
        file_object = io.BytesIO(binary_data)
        file_sha256 = hashlib.sha256(file_object.getvalue()).hexdigest()
        check_sample = do_request("GET", f"sample/sha256/{file_sha256}").json()
        if check_sample.get("data") and not resubmit:
            logging.info(f"sample found in VMRay database with sample_id {sample.get("sample_id")}")
            sample = check_sample.get('data')[0]
            submission_details = do_request("GET", f"submission/sample/{sample.get("sample_id")}").json()
            current_submission = submission_details.get("data", [])[0]
            submission_data = {
                "vmray_submission": [
                    {
                        "SubmissionID": current_submission.get("submission_id"),
                        "SubmissionURL": sample.get("sample_webif_url"),
                        "SampleID": sample.get("sample_id")
                    }
                
                ]
            }
            return func.HttpResponse(
            json.dumps(submission_data),
            headers={"Content-Type": "application/json"},
            status_code=200,
            )
        params = {}
        params['shareable'] = shareable == 'true'
        if doc_pass:
            params['document_password'] = doc_pass
        if arch_pass:
            params['archive_password'] = arch_pass
        if sample_type:
            params['sample_type'] = sample_type
        if max_jobs:
            if isinstance(max_jobs, str) and max_jobs.isdigit() or isinstance(max_jobs, int):
                params['max_jobs'] = int(max_jobs)
            else:
                raise ValueError('max_jobs arguments isn\'t a number')
        if tags:
            params['tags'] = ",".join(tags)
        if net_scheme_name:
            params['user_config'] = "{\"net_scheme_name\": \"" + str(net_scheme_name) + "\"}"
        endpoint = "sample/submit"
        files = {"sample_file" :(name, file_object)}
        response = do_request("POST", endpoint, params=params, files=files)
        submission_data = build_submission_data(response.json(), "File")
        return func.HttpResponse(
            json.dumps(submission_data),
            headers={"Content-Type": "application/json"},
            status_code=200,
        )

    except KeyError as ke:
        logging.error(f"Invalid Settings. {ke.args} configuration is missing.")
        return func.HttpResponse(
            "Invalid Settings. Configuration is missing.", status_code=500
        )
    except Exception as ex:
        logging.error(f"Exception Occured: {str(ex)}")
        return func.HttpResponse("Internal Server Exception", status_code=500)


