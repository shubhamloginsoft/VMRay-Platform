import json
import logging
from os import environ

import azure.functions as func
import requests

from .utils import *


DATE_TIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
DEFAULT_HEADERS = {"accept": "application/json", "Content-Type": "application/json"}
vmray_api_key = environ["vmrayAPIKey"]
vmrayBaseURL = environ["vmrayBaseURL"]


def do_request(endpoint, params={}, body={}):
    # import pdb; pdb.set_trace()
    headers = {
        "Authorization": f"api_key {vmray_api_key}",
        "User-Agent": "Sentinel"
    }

    try:
        logging.info(f"api key {vmray_api_key}")
        logging.info(f"api ur {vmrayBaseURL}")
        response = requests.get(
            url=f'{vmrayBaseURL}/rest/{endpoint}',
            headers=headers,
            params=params
        )
        response.raise_for_status()  # Raises HTTPError for bad responses
        logging.info(f'User-Agent: {response.request.headers.get("User-Agent")}')
        return response
    except requests.exceptions.RequestException as e:
        logging.error(f"Error in request: {e}")
        logging.error(f"Error response: {response.json().get('error_msg')}")
        return response
    
def check_id(id_to_check: int | str) -> bool:
    """Checks if parameter id_to_check is a number

    Args:
        id_to_check (int or str):

    Returns:
        bool: True if is a number, else returns error
    """
    if isinstance(id_to_check, int) or isinstance(id_to_check, str) and id_to_check.isdigit():
        return True
    raise ValueError(f"Invalid ID `{id_to_check}` provided.")



def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        sample_id = req.params.get("sample_id")
        submission_id = req.params.get("submission_id")
        sample_verdict = req.params.get("sample_verdict")
        incident_id = req.params.get("incident_id")


        if not sample_id:
            try:
                req_body = req.get_json()
            except ValueError:
                pass
            else:
                sample_id = req_body.get("sample_id")
                submission_id = req_body.get("submission_id")
                sample_verdict = req_body.get("sample_verdict")
                incident_id = req_body.get("incident_id")

        logging.info(f"sample_id: {sample_id}")
        check_id(sample_id)
        
        endpoint = f'sample/{sample_id}/iocs'
        response = do_request(endpoint)
        
        if submission_id and sample_verdict and response.status_code == 200:
            iocs_resp = response.json().get("data", {}).get('iocs', {})
            for key, value in iocs_resp.items():
                if key in utils.IOC_LIST:
                    utils.IOC_MAPPING_FUNCTION[key](value, int(sample_id), submission_id, sample_verdict, incident_id)
            indicator_list = utils.indicator_list()
            logging.info(f"length of indiactor {len(indicator_list)}")

            return func.HttpResponse(
                json.dumps({"api_resp": response.json(),"custom_resp": indicator_list}),
                headers={"Content-Type": "application/json"},
                status_code=200,
            )
        return func.HttpResponse(
                json.dumps(response.json()),
                headers={"Content-Type": "application/json"},
                status_code=200,
            )
        
    except KeyError as ke:
        logging.error(f"Invalid Settings. {ke.args} configuration is missing.")
        return func.HttpResponse(
            "Invalid Settings. Configuration is missing.", status_code=500
        )
    except Exception as ex:
        logging.error(f"Exception Occured: {str(ex)}")
        return func.HttpResponse("Internal Server Exception", status_code=500)
