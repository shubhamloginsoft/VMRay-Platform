import json
import logging
import hashlib
from datetime import datetime
from os import environ
from urllib.parse import urlencode, urlunparse

import azure.functions as func
import requests


DATE_TIME_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
DEFAULT_HEADERS = {"accept": "application/json", "Content-Type": "application/json"}
vmray_api_key = environ["vmrayAPIKey"]
vmrayBaseURL = environ["vmrayBaseURL"]

#helper function
def str_to_bool(value: str):
    if isinstance(value, str):
        value = value.strip().lower()
        if value == "false":
            return False
        elif value == "true":
            return True
    return bool(value)

resubmit = str_to_bool(environ["Resubmit"])


def do_request(method, endpoint, params={}, body={}):
    headers = {
        "Authorization": f"api_key {vmray_api_key}",
        "User-Agent": "Sentinel"
    }

    try:
        if method == "GET":
            response = requests.get(url=f'{vmrayBaseURL}/rest/{endpoint}', headers=headers)
        else:
            response = requests.post(
                url=f'{vmrayBaseURL}/rest/{endpoint}',
                headers=headers,
                params=params
            )
        response.raise_for_status()  # Raises HTTPError for bad responses
        logging.info(f'User-Agent: {response.request.headers.get("User-Agent")}')
        return response
    except requests.HTTPError as e:
        logging.error(f"Error in request: {e}")
        logging.error(f"Error response: {response.json().get('error_msg')}")
        return response


def build_submission_data(raw_response, type_):
    """Process a submission response from VMRay Platform

    Args:
        raw_response: (dict)
        type_: (str)
    """

    data = raw_response.get('data')

    jobs_list = []
    jobs = data.get('jobs', [])
    for job in jobs:
        if isinstance(job, dict):
            job_entry = {}
            job_entry['JobID'] = job.get('job_id')
            job_entry['Created'] = job.get('job_created')
            job_entry['SampleID'] = job.get('job_sample_id')
            job_entry['VMName'] = job.get('job_vm_name')
            job_entry['VMID'] = job.get('job_vm_id')
            job_entry['JobRuleSampleType'] = job.get('job_jobrule_sampletype')
            jobs_list.append(job_entry)

    samples_list = []
    samples = data.get('samples', [])
    for sample in samples:
        if isinstance(sample, dict):
            sample_entry = {}
            sample_entry['SampleID'] = sample.get('sample_id')
            sample_entry['SampleURL'] = sample.get('sample_webif_url')
            sample_entry['Created'] = sample.get('sample_created')
            sample_entry['FileName'] = sample.get('submission_filename')
            sample_entry['FileSize'] = sample.get('sample_filesize')
            sample_entry['SSDeep'] = sample.get('sample_ssdeephash')
            sample_entry['SHA1'] = sample.get('sample_sha1hash')
            samples_list.append(sample_entry)

    submissions_list = []
    submissions = data.get('submissions', [])
    for submission in submissions:
        if isinstance(submission, dict):
            submission_entry = {}
            submission_entry['SubmissionID'] = submission.get('submission_id')
            submission_entry['SubmissionURL'] = submission.get('submission_webif_url')
            submission_entry['SampleID'] = submission.get('submission_sample_id')
            submissions_list.append(submission_entry)

    entry_context = {}
    entry_context['vmray_job'] = jobs_list
    entry_context['vmray_sample'] = samples_list
    entry_context[
        'vmray_submission'
    ] = submissions_list

    return entry_context


def get_request_params(req):
    """Helper function to extract parameters from request."""
    params = dict(req.params)
    try:
        req_body = req.get_json()
        if req_body:
            params.update(req_body)
    except ValueError:
        raise
    return params


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        params = get_request_params(req)
        url = params.get("url")
        shareable = params.get("shareable")
        max_jobs = params.get("max_jobs")
        tags = params.get("tags", [])
        net_scheme_name = params.get("net_scheme_name", [])

        if not url:
            return func.HttpResponse("Url parameter is missing", status_code=400)
        url_sha256 = hashlib.sha256(url.encode()).hexdigest()
        check_sample = do_request("GET", f"sample/sha256/{url_sha256}").json()
        if check_sample.get("data"):
            sample = check_sample.get('data')[0]
            if not resubmit:
                logging.info(f"sample found in VMRay database with sample_id {sample.get('sample_id')}")
                submission_details = do_request("GET", f"submission/sample/{sample.get('sample_id')}").json()
                current_submission = submission_details.get("data", [])[0]
                submission_data = {
                    "vmray_submission": [
                        {
                            "SubmissionID": current_submission.get("submission_id"),
                            "SubmissionURL": sample.get("sample_webif_url"),
                            "SampleID": sample.get("sample_id")
                        }

                    ]
                }
                return func.HttpResponse(
                json.dumps(submission_data),
                headers={"Content-Type": "application/json"},
                status_code=200,
                )
            logging.info(f"Resubmitting found sample with sample_id {sample.get('sample_id')}")
        params = {}
        params['shareable'] = shareable == 'true'
        if max_jobs:
            if isinstance(max_jobs, str) and max_jobs.isdigit() or isinstance(max_jobs, int):
                params['max_jobs'] = int(max_jobs)
            else:
                raise ValueError('max_jobs arguments isn\'t a number')
        if tags:
            params['tags'] = ",".join(tags)
        if net_scheme_name:
            params['user_config'] = "{\"net_scheme_name\": \"" + str(net_scheme_name) + "\"}"
        endpoint = "sample/submit"
        params['sample_url'] = url
        response = do_request("POST", endpoint, params)
        submission_data = build_submission_data(response.json(), "url")
        return func.HttpResponse(
            json.dumps(submission_data),
            headers={"Content-Type": "application/json"},
            status_code=200,
        )

    except KeyError as ke:
        logging.error(f"Missing configuration: {ke.args}")
        return func.HttpResponse("Missing configuration.", status_code=400)
    except ValueError as ve:
        logging.error(f"Invalid value: {ve.args}")
        return func.HttpResponse(f"Invalid value: {ve.args}", status_code=400)
    except Exception as ex:
        logging.error(f"Exception occurred: {str(ex)}")
        return func.HttpResponse("Internal Server Error", status_code=500)


